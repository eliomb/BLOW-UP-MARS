"""Dependency-free regression tests: offline mock of LM Studio API and metadata extraction."""
import http.server
import json
import os
import socketserver
import sys
import threading
import unittest
from unittest.mock import patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'app'))
import ai

PACKETS = [dict(ts=100 + i * 0.1, len=90, src='192.0.2.1', dst='198.51.100.4', sport=40000+i,
                dport=20+i, tr='TCP', proto='TCP', flags='S', info='GET /secret', txt='password SECRET', n=i)
           for i in range(20)]

class Model(http.server.BaseHTTPRequestHandler):
    def log_message(self, *args): pass
    def do_POST(self):
        assert self.path == '/v1/chat/completions'
        data = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        prompt = data['messages'][1]['content']
        assert 'password SECRET' not in prompt and 'GET /secret' not in prompt
        assert '192.0.2.1' in prompt
        payload = json.dumps({'choices':[{'message':{'content':json.dumps({
            'summary':'Possible scanning from one source.', 'confidence':'medium',
            'findings':[{'category':'suspicious','title':'Unusual port spread','severity':'medium',
                         'detail':'20 SYN probes observed','evidence':['20 destination ports'],'recommendation':'Review flows'}],
            'narrative':'A source sent repeated SYN packets.', 'next_steps':['Correlate with firewall logs'],
            'limitations':['Metadata cannot confirm intent']})}}]}).encode()
        self.send_response(200); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(payload))); self.end_headers(); self.wfile.write(payload)

class Tests(unittest.TestCase):
    def test_aggregates_no_payload(self):
        ev = ai.observe(PACKETS)
        self.assertEqual(ev['syn_only_count'], 20)
        self.assertEqual(len(ev['scan_candidates']), 1)
        self.assertNotIn('SECRET', json.dumps(ev))
        self.assertNotIn('/secret', json.dumps(ev))
    def test_bad_model_shape(self):
        with self.assertRaises(ValueError): ai.normalize({'findings':42}, ai.observe(PACKETS))
    def test_end_to_end_model(self):
        srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Model)
        thread = threading.Thread(target=srv.serve_forever, daemon=True); thread.start()
        try:
            env = {'LM_STUDIO_HOST':'127.0.0.1', 'LM_STUDIO_PORT':str(srv.server_port), 'LM_STUDIO_MODEL':'mock-model'}
            with patch.dict(os.environ, env):
                r = ai.analyze(ai.observe(PACKETS))
            self.assertEqual(r['findings'][0]['category'], 'suspicious')
            self.assertEqual(r['evidence']['packet_count'], 20)
            self.assertEqual(r['model'], 'mock-model')
        finally: srv.shutdown(); srv.server_close()
    def test_bad_config(self):
        with patch.dict(os.environ, {'LM_STUDIO_HOST':'127.0.0.1@evil.com'}):
            with self.assertRaises(ValueError): ai.config()
        with patch.dict(os.environ, {'LM_STUDIO_PORT':'99999'}):
            with self.assertRaises(ValueError): ai.config()

if __name__ == '__main__': unittest.main()
