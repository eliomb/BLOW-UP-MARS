"""Exercise original session/packet APIs and the new AI analysis routes."""
import http.server, json, os, socket, sys, threading, unittest, urllib.request
from unittest.mock import patch
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'app'))
import server

class Endpoints(unittest.TestCase):
    def setUp(self):
        self.srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), server.H)
        self.t = threading.Thread(target=self.srv.serve_forever, daemon=True); self.t.start()
        self.base = f'http://127.0.0.1:{self.srv.server_port}'
        # Request Host contains dynamic port; caller must configure permitted Host for this test.
        server.ALLOWED.add('127.0.0.1')
    def tearDown(self):
        self.srv.shutdown(); self.srv.server_close()
    def request(self, path, obj=None):
        data = json.dumps(obj).encode() if obj is not None else None
        req = urllib.request.Request(self.base+path, data=data, headers={
            'X-Requested-With':'wirelight', **({'Content-Type':'application/json'} if data else {})})
        with urllib.request.urlopen(req) as r: return json.load(r)
    def test_original_routes_and_ai(self):
        pk=[dict(n=0, ts=10., len=64, src='192.0.2.1', dst='192.0.2.2', sport=1234,
                 dport=80, proto='HTTP', tr='TCP', flags='PA', info='GET /', txt='get /')]
        sid,_=server.new_session(pk,[b'X'*64])
        self.assertEqual(self.request('/api/packets?id='+sid)['total'], 1)
        self.assertIn('hex', self.request('/api/packet?id='+sid+'&n=0'))
        self.assertEqual(self.request('/api/ai/report?id='+sid)['report'], None)
        fake = dict(summary='HTTP traffic observed', findings=[], confidence='low', narrative='',
                    next_steps=[], limitations=[], evidence={}, generated_utc='now', model='mock')
        with patch.object(server.ai, 'analyze', return_value=fake) as mock:
            result=self.request('/api/ai/analyze', {'id':sid})
        self.assertEqual(result['report'],fake)
        self.assertEqual(mock.call_args.args[0]['packet_count'], 1)
        self.assertEqual(self.request('/api/ai/report?id='+sid)['report'],fake)
        self.assertIn('endpoint',self.request('/api/ai/config'))

if __name__ == '__main__': unittest.main()
